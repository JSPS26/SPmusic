# SPmusic 1.0

Reproductor de música local para Android. No requiere cuentas ni Internet para reproducir música almacenada en el teléfono.

## Incluye
- Biblioteca de música local mediante MediaStore.
- Carátulas incrustadas cuando el archivo las proporciona.
- Búsqueda por canción, artista y álbum.
- Favoritos persistentes.
- Cola de reproducción y controles anterior/siguiente.
- Reproducción aleatoria.
- Repetición mediante controles del sistema/Media3.
- Reproducción en segundo plano y notificación multimedia.
- Diseño oscuro con identidad SPmusic.
- Compatible con Android moderno y preparado para Android Studio.

## Compilación
Abrir la carpeta en Android Studio y ejecutar **Build > Build APK(s)**. El proyecto usa Android Gradle Plugin 9.3.0, JDK 17 y Media3 1.10.1.

Nota: este entorno no tiene instalado Android SDK/Gradle, por lo que no se ha podido producir aquí un APK binario ni verificar una compilación local. El proyecto está preparado para compilarse en Android Studio.
