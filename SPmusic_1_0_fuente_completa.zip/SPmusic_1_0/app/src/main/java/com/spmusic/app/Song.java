package com.spmusic.app;
import android.net.Uri;
public class Song { public long id; public Uri uri; public String title,artist,album; public byte[] art; public Song(long id,Uri uri,String title,String artist,String album,byte[] art){this.id=id;this.uri=uri;this.title=title;this.artist=artist;this.album=album;this.art=art;} }
